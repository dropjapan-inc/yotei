// Firebaseの設定(dj-yoteihyo)。この値は公開されても問題ない情報です。データはFirestoreのルールで守られます。
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyBTU2AjvvOKmrXbmIgAatGaiPyHafXsKT0",
  authDomain: "dj-yoteihyo.firebaseapp.com",
  projectId: "dj-yoteihyo",
  storageBucket: "dj-yoteihyo.firebasestorage.app",
  messagingSenderId: "163570833249",
  appId: "1:163570833249:web:68c9c683a4096eae325720"
};
// 通知の設定(Firebaseを有料プランにして、通知用のプログラムを置いたあとに入れる)
window.DJ_PUSH = {
  vapidKey: "BJevZeykJPPJdPm25U4Xm7XIQIvB7ko-0fr45riyvbZ0lPBLfk_6HuA201y-nMYDcAdUE9RXicx60bcxzeAp7OM",
  url: "https://djpush-163570833249.asia-northeast1.run.app"
};
